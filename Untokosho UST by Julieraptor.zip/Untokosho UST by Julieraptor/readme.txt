Hello!

Thanks for downloading this UST!

UST by Julieraptor
Instrumental by Julieraptor

Original by もんず 
http://www.nicovideo.jp/watch/sm22141948

-You MUST credit Julieraptor (@lieeorasan on Twitter) IF YOU USE THIS UST.
-You MUST adjust the UST to your voicebank. 
-Do NOT claim the tuning as your own.
-You MAY NOT REDISTRIBUTE this UST.

【CONTACT INFORMATION】
Please contact Julieraptor for any questions or concerns about this UST.
Twitter: @lieeorasan
SoundCloud: Julieraptor
YouTube: Julieraptor