Hello!

Thanks for downloading this TSSLN!
I forgot to upload this at first, sorry...

I'm a big fan of Sabrina. I hope you like my cover with Chis-A!

Chis-A (English) Cover: https://www.youtube.com/watch?v=rwV7tutHEi8

TSSLN by julieraptor

Original by Sabrina Carpenter

-You MUST credit Julieraptor (@ChulieChu on Twitter) IF YOU USE THIS UST.
-You MUST adjust the UST to your voicebank. 
-Do NOT claim the tuning as your own.
-You MAY NOT REDISTRIBUTE this UST.

【CONTACT INFORMATION】
Please contact Julieraptor for any questions or concerns about this UST.
YouTube: https://www.youtube.com/@chulie_chu
Twitter: @ChulieChu
Bluesky: @julieraptor.bsky.social
E-mail: raptorjulie@gmail.com