Hello!

Thanks for downloading this UST.

This UST includes the Tsubasa UST with VCV support.

midi by Julieraptor
UST by Julieraptor

-You MUST credit Julieraptor (@utauraptor on Twitter) IF YOU USE THIS UST.
-You MUST adjust the UST to your voicebank. 
-Do NOT claim the tuning as your own.
-You MAY NOT REDISTRIBUTE this UST.


�yCONTACT INFORMATION�z
Please contact Julieraptor for any questions or concerns about this UST.
Twitter: @utauraptor
SoundCloud: Julieraptor
YouTube: Julieraptor

password: IrohaNekomura