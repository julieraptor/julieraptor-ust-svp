Hello!

Thanks for downloading this UST/USTx!

USTx by Julieraptor

Original song by Luis Demetrio and Pablo Beltrán Ruiz, based on Michael Buble's cover with Norman Gimbel's lyrics.

LIEE Cover: https://www.youtube.com/watch?v=rITQN4eaNps

-You MUST credit Julieraptor (@ChulieChu on Twitter and @chulie_chu on Youtube) IF YOU USE THIS SVP/UST. 
Please link to both Youtube and Twitter accounts when posting.
-You MUST adjust the SVP/UST to your voicebank. 
-Do NOT claim the tuning as your own.
-You MAY NOT REDISTRIBUTE this SVP/UST.

【CONTACT INFORMATION】
Please contact Julieraptor for any questions or concerns about this SVP/UST.
Twitter: @ChulieChu @utauraptor
SoundCloud: Julieraptor
YouTube: @chulie_chu "julieraptor (UTAUraptor)"