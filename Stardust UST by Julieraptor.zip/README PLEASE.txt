Hello!

Thanks for downloading this UST.

This UST includes the Romaji + Hiragana for StaRDUsT by Sweet Revenge.

midi by Lie (Julieraptor)
UST by Lie (Julieraptor)

-You MUST credit Julieraptor (@lieeorasan on Twitter) IF YOU USE THIS UST.
-You MAY NOT REDISTRIBUTE this UST.

Original Song: https://www.youtube.com/watch?v=9G48QXJEUpI
Instrumental: https://soundcloud.com/sweet_revenge_k/stardust-nstrument-l-ver


�yCONTACT INFORMATION�z
Please contact Julieraptor (Lie) for any questions or concerns about this UST.
Twitter: @lieeorasan
SoundCloud: Julieraptor
YouTube: Julieraptor

password: sweetrevenge