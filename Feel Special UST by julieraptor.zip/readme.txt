hi owo

there are 6 usts: 

feel special_intro (hammy part, beginning and end. you have to manually pitch up 1 octave/12 semi-tones)
feel special_main (can switch from ryo and liee. add suffixes if you want)
feel special_harms (can switch from ryo and liee. add suffixes if you want)
feel special_adlibs (can switch from ryo and liee. add suffixes if you want)
feel special_rap (liee only)  
feel special_rap_harms (liee only)

thanks for commissioning me ozu uwu i love you