Hello!

Thanks for downloading this UST.

This UST includes the Chug Jug UST with CVVC and VCV support.

midi by Julieraptor
UST by Julieraptor

-You MUST credit Julieraptor (@lieeorasan on Twitter) IF YOU USE THIS UST.
-You MUST adjust the UST to your voicebank. 
-Do NOT claim the tuning as your own.
-You MAY NOT REDISTRIBUTE this UST.


�yCONTACT INFORMATION�z
Please contact Julieraptor for any questions or concerns about this UST.
Twitter: @lieeorasan
SoundCloud: Julieraptor
YouTube: Julieraptor

password: fortnite2