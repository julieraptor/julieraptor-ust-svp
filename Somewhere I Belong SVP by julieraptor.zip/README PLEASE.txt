Hello!

Thanks for downloading this SVP.

Originally this wasn't supposed to be Moca and ROSE, but I liked how they sounded here!!

Original song by Linkin Park

My cover with Miyamai Moca and ROSE: https://www.youtube.com/watch?v=-xybjadi9Tw

-You MUST credit Julieraptor (@utauraptor on Twitter) IF YOU USE THIS UST/TSSLN/SVP/etc.
-You MUST adjust the UST to your voicebank. 
-Do NOT claim the tuning as your own.
-You MAY NOT REDISTRIBUTE this UST.

More UST/TSSLN/SVP/etc: https://github.com/julieraptor/julieraptor-ust-svp

�yCONTACT INFORMATION�z
Please contact Julieraptor for any questions or concerns about this UST.
Twitter: @ChulieChu
SoundCloud: Julieraptor
YouTube: J@chulie_chu