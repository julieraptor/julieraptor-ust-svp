Hello!

Thanks for downloading this USTx! 

I also included a midi for pitch-snap/auto-tune for mixing if you want to do that in your DAW.

USTx by Julieraptor

Original song by Jonathan Coulton for Portal

LIEE Cover: https://youtu.be/7AYYl7hJB2Y
My cover: https://youtu.be/nAP_iSDA0h4 (uses the pitch-snap from the midi)


-You MUST credit Julieraptor (@utauraptor on Twitter and Youtube) IF YOU USE THIS SVP/UST. Please link to both Youtube and Twitter accounts when posting.
-You MUST adjust the SVP/UST to your voicebank. 
-Do NOT claim the tuning as your own.
-You MAY NOT REDISTRIBUTE this SVP/UST.

【CONTACT INFORMATION】
Please contact Julieraptor for any questions or concerns about this SVP/UST.
Twitter: @utauraptor
SoundCloud: Julieraptor
YouTube: Julieraptor / utauraptor