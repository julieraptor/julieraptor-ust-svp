Hello!

Thanks for downloading this UST! I can't get this out of my brain so I made LIEE sing it.

Song: 4:00 AM by Ohnuki Taeko
UST by Julieraptor

-You MUST credit Julieraptor (@lieeorasan on Twitter) IF YOU USE THIS UST.
-You MUST adjust the UST to your voicebank. 
-Do NOT claim the tuning as your own.
-You MAY NOT REDISTRIBUTE this UST.

【CONTACT INFORMATION】
Please contact Julieraptor for any questions or concerns about this UST.
Twitter: @lieeorasan
SoundCloud: Julieraptor
YouTube: Julieraptor

Password: LORDGIVEMEONEMORECHANCE