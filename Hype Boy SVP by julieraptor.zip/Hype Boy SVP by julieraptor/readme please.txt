Hello!

Thanks for downloading this SVP! Any Bunnies out there... I want to go to a NWJNS concert SOOO BADDDD

SVP by Julieraptor

Original song by NewJeans

Teto Cover: https://youtu.be/1DfGOGiCb2c
Chis-A Cover: https://www.youtube.com/watch?v=0ImVGWL4VTA


-You MUST credit Julieraptor (@utauraptor on Twitter and Youtube) IF YOU USE THIS SVP/UST. Please link to both Youtube and Twitter accounts when posting.
-You MUST adjust the SVP/UST to your voicebank. 
-Do NOT claim the tuning as your own.
-You MAY NOT REDISTRIBUTE this SVP/UST.

【CONTACT INFORMATION】
Please contact Julieraptor for any questions or concerns about this SVP/UST.
Twitter: @utauraptor
SoundCloud: Julieraptor
YouTube: Julieraptor / utauraptor