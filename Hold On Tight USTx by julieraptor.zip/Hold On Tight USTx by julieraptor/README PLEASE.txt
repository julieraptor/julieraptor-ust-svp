Hello!

Thanks for downloading this SVP.

My cover with LIEE ARPASING ENGLISH: https://youtu.be/L7qSDknsi24

�y Attribution �z

- When publishing work with these files, you are required to state the author of the original files.
- You must write the name of the author exactly as given: julieraptor
- You must link to the author's pages:
- https://www.youtube.com/@chulie_chu
- https://twitter.com/ChulieChu
- https://bsky.app/profile/julieraptor.bsky.social

You must mention the file's original type if conversion for other synthesizers is done.

�y Editing �z

- Usage of the files in other synthesizers is allowed.
- Conversion to other types of project files for other vocal synthesizers are allowed.
- This also means that you can convert it to a MIDI to use for other synthesizers.
- You are free to edit the original files.
- Even if you make heavy edits, you must credit the author of the original file (julieraptor).

�y Redistribution �z

- You may only redistribute the original files without any changes to its original format.
- If possible, please encourage people to retrieve the file from the origin by linking this website.

More UST/TSSLN/SVP/etc: https://github.com/julieraptor/julieraptor-ust-svp

�y CONTACT INFORMATION �z

Please contact Julieraptor for any questions or concerns about this UST.
Twitter: @ChulieChu
Bluesky: @julieraptor.bsky.social
SoundCloud: Julieraptor
YouTube: @chulie_chu