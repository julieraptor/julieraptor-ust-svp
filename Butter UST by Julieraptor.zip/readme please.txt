Hello!

Thanks for downloading this UST! I love this song and I had to make a UST. Jungkook looks so good :)

This UST includes the Butter UST with tune for VCV and Arpasing (get it let it roll).

UST by Julieraptor

-You MUST credit Julieraptor (@lieeorasan on Twitter) IF YOU USE THIS UST.
-You MUST adjust the UST to your voicebank. 
-Do NOT claim the tuning as your own.
-You MAY NOT REDISTRIBUTE this UST.

Original: https://www.youtube.com/watch?v=WMweEpGlu_U

【CONTACT INFORMATION】
Please contact Julieraptor for any questions or concerns about this UST.
Twitter: @lieeorasan
SoundCloud: Julieraptor
YouTube: Julieraptor

Password: KIMSEOKJIN