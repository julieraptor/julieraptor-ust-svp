Hello!

Thanks for downloading this TSSLN.

I felt like Chis-A would sound really good in this song...

Original song by Avril Lavigne

My cover with Chis-A: https://www.youtube.com/watch?v=EQj8Ju0G3Gw

-You MUST credit Julieraptor (@utauraptor on Twitter) IF YOU USE THIS UST/TSSLN/SVP/etc.
-You MUST adjust the UST to your voicebank. 
-Do NOT claim the tuning as your own.
-You MAY NOT REDISTRIBUTE this UST.

More UST/TSSLN/SVP/etc: https://github.com/julieraptor/julieraptor-ust-svp

�yCONTACT INFORMATION�z
Please contact Julieraptor for any questions or concerns about this UST.
Twitter: @ChulieChu
SoundCloud: Julieraptor
YouTube: J@chulie_chu