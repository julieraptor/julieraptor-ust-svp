Hello!

Thanks for downloading this TSSLN.

I didn't want this to be my first published original song but lately things have not been the best...

i'm so tired, I didn't even tune Chis-A at all...

This song's about feeling burnt out about job rejections and feeling like you're too old for milestones and being fans of things you like. But you persevere... painfully... but you persevere nonetheless...

Original song: https://www.youtube.com/watch?v=FRBpK_ZaNIA

-You MUST credit Julieraptor (@utauraptor on Twitter) IF YOU USE THIS UST.
-You MUST adjust the UST to your voicebank. 
-Do NOT claim the tuning as your own.
-You MAY NOT REDISTRIBUTE this UST.


�yCONTACT INFORMATION�z
Please contact Julieraptor for any questions or concerns about this UST.
Twitter: @ChulieChu
SoundCloud: Julieraptor
YouTube: J@chulie_chu