How long has it been ever since that day...?

A rearrange of A Sardine Grows From the Soil. Thanks for using this!

LIEE Cover: https://youtu.be/Oyf7AOESz8g
Instrumental: https://youtu.be/WLNJsHnH8uM

-You MUST credit Julieraptor (@utauraptor on Twitter and Youtube) IF YOU USE THIS INSTRUMENTAL. Please link to both Youtube and Twitter accounts when posting.
-Do NOT claim the instrumental as your own.
-You MAY NOT REDISTRIBUTE INSTRUMENTAL. LINK BACK TO THE ORIGINAL VIDEO WHERE YOU GOT THIS INSTRUMENTAL FROM: https://youtu.be/WLNJsHnH8uM

【CONTACT INFORMATION】
Please contact Julieraptor for any questions or concerns about this instrumental.
Twitter: @ChulieChu / @utauraptor
SoundCloud: Julieraptor
YouTube: @Chulie_Chu (utauraptor)