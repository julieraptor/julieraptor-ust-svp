Wait... they don't love you like I love you

Original song by The Yeah Yeah Yeahs

My cover with Kasane Teto: https://youtu.be/m5I4_UPiQH4

-You MUST credit Julieraptor (@utauraptor on Twitter) IF YOU USE THIS UST/TSSLN/SVP/etc.
-You MUST adjust the UST to your voicebank. 
-Do NOT claim the tuning as your own.
-You MAY NOT REDISTRIBUTE this UST.

More UST/TSSLN/SVP/etc: https://github.com/julieraptor/julieraptor-ust-svp

�yCONTACT INFORMATION�z
Please contact Julieraptor for any questions or concerns about this UST.
Twitter: @ChulieChu
SoundCloud: Julieraptor
YouTube: J@chulie_chu