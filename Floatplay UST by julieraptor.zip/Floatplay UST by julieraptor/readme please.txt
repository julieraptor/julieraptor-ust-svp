Hello!

Thanks for downloading this UST & USTX for Float Play!

UST/USTX and tuning by Julieraptor

Original song by Inabakumori

LIEE Cover: https://youtu.be/fifeciJr9Ww

Instrumental & Chorus files: https://drive.google.com/drive/folders/1Dj-z181rB4FbA3MusIr39vPbfR9TnFDt

-You MUST credit Julieraptor (@utauraptor on Twitter and Youtube) IF YOU USE THIS UST & USTX. Please link to both Youtube and Twitter accounts when posting.
-You MUST adjust the UST & USTX to your voicebank. 
-Do NOT claim the tuning as your own.
-You MAY NOT REDISTRIBUTE this UST & USTX.

【CONTACT INFORMATION】
Please contact Julieraptor for any questions or concerns about this SVP.
Twitter: @utauraptor
SoundCloud: Julieraptor
YouTube: Julieraptor / utauraptor