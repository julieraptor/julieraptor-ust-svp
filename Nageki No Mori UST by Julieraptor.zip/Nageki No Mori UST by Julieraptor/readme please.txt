Hello!

Thanks for downloading this UST! This is the short version of Nageki No Mori. 

Feel free to expand it to the full song, but please credit me for the base UST.

The Eng UST contains only the English part, in Arpasing. The Main UST has all the lyrics and is VCV compatible.

UST by Julieraptor

-You MUST credit Julieraptor (@lieeorasan on Twitter) IF YOU USE THIS UST.

-Please link to my Youtube when posting the cover. https://www.youtube.com/channel/UCWydCTZjtDzWUgPVE_2Ff_A

-You MUST adjust the UST to your voicebank. 

-Do NOT claim the tuning as your own.

-You MAY NOT REDISTRIBUTE this UST.

【CONTACT INFORMATION】
Please contact Julieraptor for any questions or concerns about this UST.
Twitter: @lieeorasan
SoundCloud: Julieraptor
YouTube: Julieraptor

Password: use_soda