Hello!

Thanks for downloading this UST.

This UST includes the Meiro UST with tune and no tune for VCV.

midi by Lie (Julieraptor)
UST by Lie (Julieraptor)

-You MUST credit Julieraptor (@lieeorasan on Twitter) IF YOU USE THIS UST.
-You MUST adjust the UST to your voicebank. 
-Do NOT claim the tuning as your own.
-You MAY NOT REDISTRIBUTE this UST.

Original Song: https://www.youtube.com/watch?v=jyuA70SE4pI
Instrumental: https://www.fanbox.cc/@sui/posts/1067524


�yCONTACT INFORMATION�z
Please contact Julieraptor (Lie) for any questions or concerns about this UST.
Twitter: @lieeorasan
SoundCloud: Julieraptor
YouTube: Julieraptor

password: scp087