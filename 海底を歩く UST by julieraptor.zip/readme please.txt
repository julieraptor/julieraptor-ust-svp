Hello!

Thanks for downloading this UST/USTx! It is distributed as untuned.

USTx by Julieraptor

Original song by towa

PLEASE LISTEN TO TOWA MUSIC!!!!!!!!!!!!!!!!!!!!!!!!!!!!

LIEE Cover: https://youtu.be/8T8dHHEBfTI
Original: https://www.youtube.com/watch?v=gZSR4Xg8HKE

-You MUST credit Julieraptor (@ChulieChu on Twitter and @chulie_chu on Youtube) IF YOU USE THIS SVP/UST. 
Please link to both Youtube and Twitter accounts when posting.
-You MUST adjust the SVP/UST to your voicebank. 
-Do NOT claim the tuning as your own.
-You MAY NOT REDISTRIBUTE this SVP/UST.

【CONTACT INFORMATION】
Please contact Julieraptor for any questions or concerns about this SVP/UST.
Twitter: @ChulieChu @utauraptor
SoundCloud: Julieraptor
YouTube: @chulie_chu "julieraptor (UTAUraptor)"