Hello!

Thanks for downloading this UST/USTx! I woke up this morning and I'm like... "I have to cover this song with Melly and LIEE..."

SVP/UST/USTx by Julieraptor
+ Autotune using Mai and Teto SynthV (edited transitions and vibratos in UST)

Original song by FantasticPlanets

Diffsinger LIEE + Yumelia Cover: https://youtu.be/uR4digq4ph4

-You MUST credit Julieraptor (@utauraptor on Twitter and Youtube) IF YOU USE THIS SVP/UST. Please link to both Youtube and Twitter accounts when posting.
-You MUST adjust the SVP/UST to your voicebank. 
-Do NOT claim the tuning as your own.
-You MAY NOT REDISTRIBUTE this SVP/UST.

【CONTACT INFORMATION】
Please contact Julieraptor for any questions or concerns about this SVP/UST.
Twitter: @utauraptor
SoundCloud: Julieraptor
YouTube: Julieraptor / utauraptor