Hello!

Thanks for downloading this UST/USTx! 

I've been listening to a lot of TLT lately again.

I lost the midi lol but you can just export it from the USTx

USTx by Julieraptor

Original song by The Living Tombstone

LIEE Cover: https://youtu.be/LiRALJ9S3Ww

-You MUST credit Julieraptor (@utauraptor on Twitter and Youtube) IF YOU USE THIS SVP/UST. Please link to both Youtube and Twitter accounts when posting.
-You MUST adjust the SVP/UST to your voicebank. 
-Do NOT claim the tuning as your own.
-You MAY NOT REDISTRIBUTE this SVP/UST.

【CONTACT INFORMATION】
Please contact Julieraptor for any questions or concerns about this SVP/UST.
Twitter: @utauraptor
SoundCloud: Julieraptor
YouTube: Julieraptor / utauraptor