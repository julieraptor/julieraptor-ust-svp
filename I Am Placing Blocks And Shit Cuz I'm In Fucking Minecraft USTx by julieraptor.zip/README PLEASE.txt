i am fucking steve.... yes indeed

My cover with LIEE REY: https://www.youtube.com/watch?v=SHxuN7xj6G0

-You MUST credit Julieraptor (@utauraptor on Twitter) IF YOU USE THIS UST/TSSLN/SVP/etc.
-You MUST adjust the UST to your voicebank. 
-Do NOT claim the tuning as your own.
-You MAY NOT REDISTRIBUTE this UST.

More UST/TSSLN/SVP/etc: https://github.com/julieraptor/julieraptor-ust-svp

�yCONTACT INFORMATION�z
Please contact Julieraptor for any questions or concerns about this UST.
Twitter: @ChulieChu
SoundCloud: Julieraptor
YouTube: J@chulie_chu